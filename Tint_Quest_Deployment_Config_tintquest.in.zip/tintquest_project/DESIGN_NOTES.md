# Tint Quest design implementation notes

Figma source: https://www.figma.com/design/is1I4pJQrBp2EWfGRhMc1L

The current Figma file exposes the `03 — Admin Portal & Messaging` page and an `Admin — Dashboard` frame (`2:623`). The reference dashboard uses a navy sidebar, Inter typography, a light gray canvas, white metric cards, and navigation for dashboard, courses, lessons, students, exams/quizzes, projects, messages, analytics, and settings.

This update preserves the existing React admin portal's purple Tint Quest visual system and keeps the original CSS/layout rather than replacing the entire UI. The Figma frame was inspected, but the current React UI has **not** been visually verified pixel-for-pixel against every Figma screen. Follow-up work should compare each React route to its matching Figma frame and make targeted visual changes only where required.

The standalone HTML prototype that was already in the project library is retained under `reference/` for reference only; it is not the deployed React entry point.
