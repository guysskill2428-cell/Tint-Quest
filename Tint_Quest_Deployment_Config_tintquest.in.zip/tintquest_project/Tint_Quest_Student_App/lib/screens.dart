import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

const ink = Color(0xFF201A35);
const purple = Color(0xFF6C4CE8);
const muted = Color(0xFF827C93);
const line = Color(0xFFEAE6F2);

class StudentShell extends StatefulWidget {
  const StudentShell({super.key});
  @override
  State<StudentShell> createState() => _StudentShellState();
}

class _StudentShellState extends State<StudentShell> {
  int index = 0;
  final pages = const [
    HomeScreen(),
    CoursesScreen(),
    LearningProgressScreen(),
    CompilerScreen(),
    MessagesScreen(),
    NotificationsScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tint Quest', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: purple, letterSpacing: -.5)),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () => setState(() => index = 5),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Colors.white,
        child: SafeArea(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(22, 24, 22, 18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Tint Quest', style: TextStyle(color: purple, fontSize: 24, fontWeight: FontWeight.w800)),
                SizedBox(height: 5),
                Text('Student workspace', style: TextStyle(color: muted)),
              ]),
            ),
            const Divider(color: line),
            _drawerItem(Icons.home_rounded, 'Home', 0),
            _drawerItem(Icons.person_outline_rounded, 'Profile', 6),
            _drawerItem(Icons.chat_bubble_outline_rounded, 'Messages', 4),
            const Spacer(),
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('Learn • Build • Grow', style: TextStyle(color: muted)),
            ),
          ]),
        ),
      ),
      body: IndexedStack(index: index, children: pages),
      floatingActionButton: index == 0
          ? FloatingActionButton.extended(
              onPressed: () => setState(() => index = 3),
              backgroundColor: purple,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.code_rounded),
              label: const Text('Open Compiler'),
            )
          : null,
    );
  }

  Widget _drawerItem(IconData icon, String title, int target) => ListTile(
    leading: Icon(icon, color: index == target ? purple : muted),
    title: Text(title, style: TextStyle(color: index == target ? purple : ink, fontWeight: index == target ? FontWeight.w700 : FontWeight.w500)),
    selected: index == target,
    selectedTileColor: const Color(0xFFF1EDFF),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    onTap: () { setState(() => index = target); Navigator.pop(context); },
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Welcome back, Student 👋', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: ink)),
    const SizedBox(height: 8),
    const Text('Keep learning. You are making progress.', style: TextStyle(color: muted)),
    const SizedBox(height: 22),
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF7658F0), Color(0xFF5436C8)]), borderRadius: BorderRadius.circular(22)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('YOUR LEARNING JOURNEY', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
        SizedBox(height: 10),
        Text('You are doing great!', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
        SizedBox(height: 8),
        Text('Continue your course and complete the next lesson.', style: TextStyle(color: Colors.white)),
        SizedBox(height: 18),
        LinearProgressIndicator(value: .68, minHeight: 8, backgroundColor: Color(0x668FFFFFF), color: Colors.white),
        SizedBox(height: 8),
        Text('68% overall progress', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
    ),
    const SizedBox(height: 22),
    const SectionTitle('Quick overview'),
    const SizedBox(height: 12),
    const Row(children: [
      Expanded(child: StatCard(label: 'Courses', value: '4', icon: Icons.menu_book_rounded)),
      SizedBox(width: 12),
      Expanded(child: StatCard(label: 'Projects', value: '3/5', icon: Icons.rocket_launch_rounded)),
    ]),
    const SizedBox(height: 12),
    const Row(children: [
      Expanded(child: StatCard(label: 'Lessons', value: '24', icon: Icons.play_lesson_rounded)),
      SizedBox(width: 12),
      Expanded(child: StatCard(label: 'Quiz average', value: '82%', icon: Icons.auto_graph_rounded)),
    ]),
    const SizedBox(height: 22),
    const SectionTitle('Continue learning'),
    const SizedBox(height: 12),
    CourseTile(title: 'Python Programming', subtitle: 'Module 4 • Functions & Lists', progress: .72, icon: Icons.code_rounded,
      onTap: () => openCourse(context, 'Python Programming')),
    CourseTile(title: 'Web Development', subtitle: 'Module 2 • CSS Layouts', progress: .46, icon: Icons.language_rounded,
      onTap: () => openCourse(context, 'Web Development')),
    const SizedBox(height: 90),
  ]);
}

class CoursesScreen extends StatelessWidget {
  const CoursesScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'My Courses', subtitle: 'Your enrolled courses and lesson progress'),
    const SizedBox(height: 18),
    CourseTile(title: 'Python Programming', subtitle: '12 of 16 lessons completed', progress: .75, icon: Icons.code_rounded,
      onTap: () => openCourse(context, 'Python Programming')),
    CourseTile(title: 'Web Development', subtitle: '7 of 15 lessons completed', progress: .47, icon: Icons.language_rounded,
      onTap: () => openCourse(context, 'Web Development')),
    CourseTile(title: 'Database Fundamentals', subtitle: '5 of 10 lessons completed', progress: .50, icon: Icons.storage_rounded,
      onTap: () => openCourse(context, 'Database Fundamentals')),
    CourseTile(title: 'Problem Solving', subtitle: 'All lessons • 60% complete', progress: .60, icon: Icons.psychology_alt_rounded,
      onTap: () => openCourse(context, 'Problem Solving')),
  ]);
}

class LearningProgressScreen extends StatelessWidget {
  const LearningProgressScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'Learning Progress', subtitle: 'Track your progress, mistakes and next steps'),
    const SizedBox(height: 18),
    const CardBox(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Overall course completion', style: TextStyle(color: ink, fontWeight: FontWeight.w700)),
      SizedBox(height: 14),
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('68%', style: TextStyle(fontSize: 34, color: purple, fontWeight: FontWeight.w800)),
        SizedBox(width: 8),
        Padding(padding: EdgeInsets.only(bottom: 6), child: Text('completed', style: TextStyle(color: muted))),
      ]),
      SizedBox(height: 8),
      LinearProgressIndicator(value: .68, minHeight: 9, color: purple, backgroundColor: Color(0xFFECE7FB)),
      SizedBox(height: 12),
      Text('24 lessons completed • 11 lessons remaining', style: TextStyle(color: muted)),
    ])),
    const SizedBox(height: 16),
    const SectionTitle('Your projects'),
    const SizedBox(height: 10),
    const CardBox(child: Column(children: [
      ProgressLine(title: 'Completed projects', value: '3', icon: Icons.check_circle_outline_rounded, color: Color(0xFF1C9B71)),
      Divider(color: line),
      ProgressLine(title: 'Projects remaining', value: '2', icon: Icons.pending_actions_rounded, color: purple),
      Divider(color: line),
      ProgressLine(title: 'Next project', value: 'Portfolio Website', icon: Icons.web_rounded, color: muted),
    ])),
    const SizedBox(height: 16),
    const SectionTitle('Mistakes to improve'),
    const SizedBox(height: 10),
    const NoticeTile(title: 'Python: list index out of range', body: 'Review list indexes and loop boundaries.', icon: Icons.bug_report_outlined),
    const NoticeTile(title: 'Web: CSS alignment issue', body: 'Practise Flexbox alignment and spacing.', icon: Icons.tips_and_updates_outlined),
    const SizedBox(height: 16),
    const SectionTitle('Next steps'),
    const SizedBox(height: 10),
    const NoticeTile(title: '1. Finish Functions lesson', body: 'Estimated time: 20 minutes', icon: Icons.looks_one_outlined),
    const NoticeTile(title: '2. Retry the quiz', body: 'Target score: 80% or higher', icon: Icons.looks_two_outlined),
    const NoticeTile(title: '3. Submit Portfolio Website', body: 'Upload source code and README/notes.', icon: Icons.looks_3_outlined),
  ]);
}

class CompilerScreen extends StatefulWidget {
  const CompilerScreen({super.key});
  @override
  State<CompilerScreen> createState() => _CompilerScreenState();
}
class _CompilerScreenState extends State<CompilerScreen> {
  String language = 'Python 3';
  final code = TextEditingController(text: 'print("Hello, Tint Quest!")\\n');
  String output = 'Run your code to see output here.';
  bool ran = false;
  @override
  void dispose() { code.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'Online Compiler', subtitle: 'Write, run and inspect your code'),
    const SizedBox(height: 16),
    DropdownButtonFormField<String>(
      value: language,
      decoration: const InputDecoration(labelText: 'Programming language'),
      items: const ['Python 3', 'HTML / CSS', 'Java', 'C', 'C++'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
      onChanged: (v) { if (v != null) setState(() => language = v); },
    ),
    const SizedBox(height: 12),
    Container(
      decoration: BoxDecoration(color: const Color(0xFF201A35), borderRadius: BorderRadius.circular(16)),
      padding: const EdgeInsets.all(14),
      child: TextField(
        controller: code, minLines: 10, maxLines: 16,
        style: const TextStyle(fontFamily: 'monospace', color: Color(0xFFF1EDFF), fontSize: 13, height: 1.5),
        decoration: const InputDecoration(filled: false, border: InputBorder.none, hintText: 'Write code here...', hintStyle: TextStyle(color: Colors.white54)),
      ),
    ),
    const SizedBox(height: 12),
    Row(children: [
      Expanded(child: FilledButton.icon(onPressed: () => setState(() { ran = true; output = 'Demo preview only. Connect the secure Flask execution endpoint to run real code.'; }), icon: const Icon(Icons.play_arrow_rounded), label: const Text('Run Code'))),
      const SizedBox(width: 10),
      OutlinedButton.icon(onPressed: () { code.clear(); setState(() { ran = false; output = 'Editor reset.'; }); }, icon: const Icon(Icons.restart_alt_rounded), label: const Text('Reset')),
    ]),
    const SizedBox(height: 18),
    const SectionTitle('Output / Visual Preview'),
    const SizedBox(height: 10),
    CardBox(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.terminal_rounded, color: purple), const SizedBox(width: 8), const Text('Console output', style: TextStyle(fontWeight: FontWeight.w700, color: ink)), const Spacer(), if (ran) const Text('DEMO', style: TextStyle(color: muted, fontSize: 11, fontWeight: FontWeight.w700))]),
      const SizedBox(height: 12),
      Text(output, style: const TextStyle(color: muted, height: 1.45)),
      if (language == 'HTML / CSS') ...[
        const SizedBox(height: 16),
        Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFFF1EDFF), borderRadius: BorderRadius.circular(12)), child: const Column(children: [Icon(Icons.web_rounded, size: 30, color: purple), SizedBox(height: 8), Text('Web preview area', style: TextStyle(color: ink, fontWeight: FontWeight.w700)), Text('Actual HTML preview requires a sandboxed WebView.', style: TextStyle(color: muted), textAlign: TextAlign.center)])),
      ],
    ])),
    const SizedBox(height: 10),
    const Text('Safety note: never execute student code directly on the main API server. Use a restricted sandbox with resource limits.', style: TextStyle(color: muted, fontSize: 12)),
  ]);
}

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});
  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}
class _MessagesScreenState extends State<MessagesScreen> {
  final input = TextEditingController();
  final messages = <String>['Hi! Ask your course questions here.'];
  @override
  void dispose() { input.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Column(children: [
    const Padding(padding: EdgeInsets.fromLTRB(20, 20, 20, 14), child: PageHeading(title: 'Messages', subtitle: 'Private chat with your admin')),
    Expanded(child: ListView(padding: const EdgeInsets.all(20), children: [
      for (final message in messages)
        Align(alignment: Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(13), constraints: const BoxConstraints(maxWidth: 300), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: line), borderRadius: BorderRadius.circular(16)), child: Text(message, style: const TextStyle(color: ink)))),
    ])),
    SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
      Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Write a message...', contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12)))),
      const SizedBox(width: 8),
      IconButton.filled(onPressed: () { final value = input.text.trim(); if (value.isNotEmpty) setState(() { messages.add(value); input.clear(); }); }, icon: const Icon(Icons.send_rounded), style: IconButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.white)),
    ]))),
  ]);
}

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [
    PageHeading(title: 'Notifications', subtitle: 'Updates about courses, exams and projects'),
    SizedBox(height: 18),
    NoticeTile(title: 'New lesson available', body: 'Python Programming • Functions and Lists', icon: Icons.menu_book_rounded),
    NoticeTile(title: 'Project deadline reminder', body: 'Portfolio Website is due this Friday.', icon: Icons.assignment_outlined),
    NoticeTile(title: 'Quiz result published', body: 'Web Development • Score: 82%', icon: Icons.emoji_events_outlined),
    NoticeTile(title: 'Admin message', body: 'Please review the feedback on your last submission.', icon: Icons.chat_bubble_outline_rounded),
  ]);
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'Profile', subtitle: 'Your account and security settings'),
    const SizedBox(height: 20),
    const CardBox(child: Row(children: [
      CircleAvatar(radius: 30, backgroundColor: Color(0xFFEDE7FF), child: Icon(Icons.person_rounded, color: purple, size: 32)),
      SizedBox(width: 14),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Student Name', style: TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 17)), SizedBox(height: 4), Text('student@example.com', style: TextStyle(color: muted))]),
    ])),
    const SizedBox(height: 16),
    CardBox(child: Column(children: [
      ListTile(leading: const Icon(Icons.lock_outline_rounded, color: purple), title: const Text('Security settings'), subtitle: const Text('Password and login protection'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SecurityScreen()))),
      const Divider(color: line, height: 1),
      ListTile(leading: const Icon(Icons.logout_rounded, color: Color(0xFFD04444)), title: const Text('Log out'), subtitle: const Text('Sign out of this device'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LogoutScreen()))),
    ])),
  ]);
}

class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Security & Logout')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const NoticeTile(title: 'Password', body: 'Change your password after connecting the account API.', icon: Icons.password_rounded),
    const NoticeTile(title: 'Login activity', body: 'Recent sessions will appear here when backend tracking is enabled.', icon: Icons.devices_rounded),
    const NoticeTile(title: 'Two-step verification', body: 'Additional verification can be enabled when implemented by the backend.', icon: Icons.verified_user_outlined),
    const SizedBox(height: 14),
    FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LogoutScreen())), child: const Text('Log out')),
  ]));
}

class LogoutScreen extends StatelessWidget {
  const LogoutScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Log out')), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: CardBox(child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.logout_rounded, color: purple, size: 42),
    const SizedBox(height: 14),
    const Text('Ready to log out?', style: TextStyle(color: ink, fontSize: 21, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    const Text('You can sign in again at any time.', style: TextStyle(color: muted), textAlign: TextAlign.center),
    const SizedBox(height: 20),
    SizedBox(width: double.infinity, child: FilledButton(onPressed: () => showDialog(context: context, builder: (ctx) => AlertDialog(title: const Text('Backend required'), content: const Text('This UI demo does not have a real signed-in session yet. Connect Flask authentication to implement secure logout.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))])), child: const Text('Confirm log out'))),
    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
  ])))));
}

class PageHeading extends StatelessWidget {
  const PageHeading({super.key, required this.title, required this.subtitle});
  final String title, subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(color: ink, fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -.5)),
    const SizedBox(height: 6),
    Text(subtitle, style: const TextStyle(color: muted, height: 1.4)),
  ]);
}
class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key});
  final String title;
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(color: ink, fontSize: 17, fontWeight: FontWeight.w800));
}
class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  final String label, value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => CardBox(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: purple, size: 22), const SizedBox(height: 12),
    Text(value, style: const TextStyle(color: ink, fontSize: 24, fontWeight: FontWeight.w800)),
    const SizedBox(height: 4), Text(label, style: const TextStyle(color: muted)),
  ]));
}
void openCourse(BuildContext context, String courseName) {
  Navigator.push(context, MaterialPageRoute(
    builder: (_) => CourseDetailScreen(courseName: courseName),
  ));
}

class CourseTile extends StatelessWidget {
  const CourseTile({super.key, required this.title, required this.subtitle, required this.progress, required this.icon, this.onTap});
  final String title, subtitle;
  final double progress;
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: CardBox(child: Column(children: [
        Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: const Color(0xFFF1EDFF), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: purple)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
          ])),
          Text('${(progress * 100).round()}%', style: const TextStyle(color: purple, fontWeight: FontWeight.w800)),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: muted),
        ]),
        const SizedBox(height: 14),
        LinearProgressIndicator(value: progress, minHeight: 6, color: purple, backgroundColor: const Color(0xFFECE7FB), borderRadius: BorderRadius.circular(20)),
      ])),
    ),
  );
}

class CourseLesson {
  const CourseLesson(this.title, this.duration, this.description);
  final String title;
  final String duration;
  final String description;
}

class CourseDetailScreen extends StatelessWidget {
  const CourseDetailScreen({super.key, required this.courseName});
  final String courseName;

  List<CourseLesson> get lessons {
    switch (courseName) {
      case 'Python Programming':
        return const [
          CourseLesson('Introduction to Python', '08:20', 'Learn what Python is and where it is used.'),
          CourseLesson('Variables and Data Types', '12:45', 'Create variables and understand common data types.'),
          CourseLesson('Conditions and Loops', '15:10', 'Practise if statements, for loops and while loops.'),
          CourseLesson('Functions and Lists', '18:30', 'Write reusable functions and work with lists.'),
          CourseLesson('Mini Project: Number Guessing', '20:00', 'Apply Python basics in a small project.'),
        ];
      case 'Web Development':
        return const [
          CourseLesson('How the Web Works', '07:40', 'Understand browsers, websites and web pages.'),
          CourseLesson('HTML Page Structure', '13:15', 'Build a page using headings, links, images and sections.'),
          CourseLesson('CSS Basics', '14:30', 'Style a page with colours, fonts and spacing.'),
          CourseLesson('CSS Flexbox and Layouts', '17:25', 'Arrange responsive page elements using Flexbox.'),
          CourseLesson('Mini Project: Personal Website', '22:00', 'Combine HTML and CSS to build a simple website.'),
        ];
      case 'Database Fundamentals':
        return const [
          CourseLesson('Introduction to Databases', '09:10', 'Understand tables, records and database concepts.'),
          CourseLesson('SQL SELECT Queries', '13:20', 'Retrieve records using SELECT and WHERE.'),
          CourseLesson('Insert, Update and Delete', '15:00', 'Learn the basic SQL data modification commands.'),
          CourseLesson('Relationships and Joins', '18:15', 'Connect related tables using joins.'),
        ];
      default:
        return const [
          CourseLesson('Problem Solving Basics', '08:00', 'Break a problem into smaller steps.'),
          CourseLesson('Algorithms and Flowcharts', '12:10', 'Plan a solution before writing code.'),
          CourseLesson('Practise with Examples', '16:30', 'Work through beginner-friendly problems.'),
        ];
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(courseName)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF7658F0), Color(0xFF5436C8)]),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('COURSE LEARNING PATH', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
          const SizedBox(height: 8),
          Text(courseName, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('${lessons.length} video lessons • Tap any lesson to watch', style: const TextStyle(color: Colors.white)),
          const SizedBox(height: 16),
          const LinearProgressIndicator(value: .35, minHeight: 7, backgroundColor: Color(0x668FFFFFF), color: Colors.white),
        ]),
      ),
      const SizedBox(height: 22),
      const SectionTitle('Course lessons'),
      const SizedBox(height: 10),
      for (int i = 0; i < lessons.length; i++)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: CardBox(child: ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Container(
              width: 46, height: 46,
              decoration: BoxDecoration(color: const Color(0xFFF1EDFF), borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.play_circle_fill_rounded, color: purple, size: 29),
            ),
            title: Text('${i + 1}. ${lessons[i].title}', style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 5),
              child: Text('${lessons[i].duration}  •  ${lessons[i].description}', style: const TextStyle(color: muted, height: 1.35)),
            ),
            trailing: const Icon(Icons.chevron_right_rounded, color: muted),
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => VideoLessonScreen(
                courseName: courseName,
                lesson: lessons[i],
                lessonNumber: i + 1,
              ),
            )),
          )),
        ),
    ]),
  );
}

class VideoLessonScreen extends StatefulWidget {
  const VideoLessonScreen({super.key, required this.courseName, required this.lesson, required this.lessonNumber});
  final String courseName;
  final CourseLesson lesson;
  final int lessonNumber;

  @override
  State<VideoLessonScreen> createState() => _VideoLessonScreenState();
}

class _VideoLessonScreenState extends State<VideoLessonScreen> {
  // Replace this sample video URL with the real hosted video URL for each lesson.
  static const sampleVideoUrl = 'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4';
  late final VideoPlayerController _controller;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(sampleVideoUrl))
      ..initialize().then((_) {
        if (mounted) setState(() {});
      }).catchError((_) {
        if (mounted) setState(() => _hasError = true);
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Lesson ${widget.lessonNumber}')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Text(widget.courseName, style: const TextStyle(color: purple, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text(widget.lesson.title, style: const TextStyle(color: ink, fontSize: 23, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text('${widget.lesson.duration} • Video lesson', style: const TextStyle(color: muted)),
      const SizedBox(height: 18),
      ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Container(
          color: const Color(0xFF201A35),
          width: double.infinity,
          child: AspectRatio(
            aspectRatio: _controller.value.isInitialized ? _controller.value.aspectRatio : 16 / 9,
            child: _hasError
              ? const Center(child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('Video could not load. Check your internet connection or replace the sample URL with your lesson video URL.', style: TextStyle(color: Colors.white), textAlign: TextAlign.center),
                ))
              : !_controller.value.isInitialized
                ? const Center(child: CircularProgressIndicator(color: Colors.white))
                : Stack(alignment: Alignment.bottomCenter, children: [
                    VideoPlayer(_controller),
                    VideoProgressIndicator(_controller, allowScrubbing: true, padding: const EdgeInsets.all(10), colors: const VideoProgressColors(playedColor: purple, bufferedColor: Colors.white54, backgroundColor: Colors.white24)),
                    Center(
                      child: IconButton(
                        iconSize: 58,
                        color: Colors.white,
                        icon: Icon(_controller.value.isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded),
                        onPressed: () => setState(() {
                          _controller.value.isPlaying ? _controller.pause() : _controller.play();
                        }),
                      ),
                    ),
                  ]),
          ),
        ),
      ),
      const SizedBox(height: 20),
      const SectionTitle('About this lesson'),
      const SizedBox(height: 8),
      CardBox(child: Text(widget.lesson.description, style: const TextStyle(color: muted, height: 1.5))),
      const SizedBox(height: 16),
      const NoticeTile(
        title: 'Video setup note',
        body: 'This screen is connected to a sample video so you can test navigation and playback. Replace sampleVideoUrl with the real video URL for each lesson before publishing.',
        icon: Icons.info_outline_rounded,
      ),
      FilledButton.icon(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.check_circle_outline_rounded),
        label: const Text('Finish lesson / Back to lessons'),
      ),
    ]),
  );
}

class CardBox extends StatelessWidget {
  const CardBox({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: line), borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 4))]), child: child);
}
class ProgressLine extends StatelessWidget {
  const ProgressLine({super.key, required this.title, required this.value, required this.icon, required this.color});
  final String title, value;
  final IconData icon;
  final Color color;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 9), child: Row(children: [
    Icon(icon, color: color), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: ink))), Text(value, style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
  ]));
}
class NoticeTile extends StatelessWidget {
  const NoticeTile({super.key, required this.title, required this.body, required this.icon});
  final String title, body;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: line), borderRadius: BorderRadius.circular(16)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Container(width: 40, height: 40, decoration: BoxDecoration(color: const Color(0xFFF1EDFF), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: purple, size: 21)),
    const SizedBox(width: 12),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w700)),
      const SizedBox(height: 5), Text(body, style: const TextStyle(color: muted, height: 1.4)),
    ])),
  ]));
}
