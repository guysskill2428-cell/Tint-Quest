import 'package:flutter/material.dart';
import 'screens.dart';

void main() => runApp(const TintQuestApp());

class TintQuestApp extends StatelessWidget {
  const TintQuestApp({super.key});

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF6C4CE8);
    return MaterialApp(
      title: 'Tint Quest',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, primary: purple),
        scaffoldBackgroundColor: const Color(0xFFF8F7FC),
        fontFamily: 'Inter',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF8F7FC),
          foregroundColor: Color(0xFF201A35),
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE7E2F1)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE7E2F1)),
          ),
        ),
      ),
      home: const StudentShell(),
    );
  }
}
