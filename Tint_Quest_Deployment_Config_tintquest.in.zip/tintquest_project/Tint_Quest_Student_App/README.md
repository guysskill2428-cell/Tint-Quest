# Tint Quest — Student Android App (Flutter)

This is the separate **Student Android app** starter. It does not modify the Admin Web Portal or the Figma file.

## Included screens
- Home dashboard
- My Courses
- Learning Progress (completion, project status, common mistakes, next steps)
- Online Compiler UI (language picker, editor, run/reset, output/preview placeholder)
- Private Messages UI
- Notifications
- Profile
- Security & Logout
- API service starter for a self-hosted Flask backend

## Important status
This is a runnable **front-end starter / UI prototype**, not a production-ready app. Demo values are hard-coded. Chat sending is local to the screen. The compiler Run button intentionally does not execute arbitrary code. Authentication, real student records, notifications, progress, chat persistence, password changes, and logout must be connected to the Flask backend and MySQL database.

The Figma MCP access limit prevented fetching the current frame screenshots/design context during this run, so this code follows the established Tint Quest purple theme and Inter-style typography described in the project history; it is **not verified pixel-for-pixel against every Figma frame**.

## Requirements
- Flutter stable SDK
- Android Studio / Android SDK
- Node is not required for the Flutter app
- Your own Flask API + MySQL server for live data

## Prepare and run
This source archive contains `lib/` and `pubspec.yaml`, but does not include generated Android platform files. From this folder, create the Android platform scaffold once, then run the app:
```bash
flutter create --platforms=android .
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:5000/api
```

Build an Android APK:
```bash
flutter build apk --release
```
APK output:
`build/app/outputs/flutter-apk/app-release.apk`

Build an Android App Bundle for Google Play:
```bash
flutter build appbundle --release
```
AAB output:
`build/app/outputs/bundle/release/app-release.aab`

## Backend connection
`lib/api_service.dart` contains a minimal HTTP client and login request helper. The current screen widgets are still mostly prototype screens; authentication/session state and screen-by-screen API loading must be wired before production release.
- Android emulator: `http://10.0.2.2:5000/api`
- Physical Android device: use your development PC's LAN IP, e.g. `http://192.168.x.x:5000/api`
- Production: use your HTTPS domain.

Do not ship credentials in the mobile app. Use short-lived access tokens, server-side authorization, input validation, rate limits, HTTPS, and secure token storage. The sample API client is not yet an authentication implementation.

## Suggested Flask endpoints to implement
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/student/me`
- `GET /api/student/courses`
- `GET /api/student/progress`
- `GET /api/student/notifications`
- `GET /api/student/messages`
- `POST /api/student/messages`
- `POST /api/student/projects`
- `POST /api/compiler/run` (only through an isolated sandbox; never run untrusted code inside the Flask API process)

## Next integration stage
1. Implement Flask auth and MySQL schema.
2. Replace sample values with API responses.
3. Persist auth tokens securely and add session expiry.
4. Implement real message and notification APIs.
5. Implement compiler execution in an isolated, resource-limited sandbox.
6. Test Android permissions, network errors, loading/empty/error states, and account security.


## Course navigation and video lesson pages

The course cards on Home and My Courses are now tappable. Selecting Python Programming, Web Development, Database Fundamentals, or Problem Solving opens a course lesson list. Selecting a lesson opens a video player page.

The player currently uses a public sample MP4 so you can test navigation and playback. Replace `sampleVideoUrl` in `lib/screens.dart` with the real hosted video URL for your lesson before release. All lessons currently use the same sample video; real lesson-specific content has not been supplied.

Run these commands after extracting the ZIP:

```bash
flutter pub get
flutter run
```
