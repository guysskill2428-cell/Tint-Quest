"""Tint Quest self-hosted API: Flask + MySQL. No hosted backend service required."""
import os
import re
from datetime import timedelta
from functools import wraps
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, get_jwt, get_jwt_identity, jwt_required
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", ""),
    JWT_SECRET_KEY=os.environ.get("JWT_SECRET_KEY", ""),
    JWT_ACCESS_TOKEN_EXPIRES=timedelta(minutes=int(os.getenv("JWT_MINUTES", "30"))),
    SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL", "mysql+pymysql://root:password@127.0.0.1:3306/tint_quest"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    MAX_CONTENT_LENGTH=10 * 1024 * 1024,
)
if not app.config["SECRET_KEY"] or not app.config["JWT_SECRET_KEY"]:
    if os.getenv("APP_ENV", "development") == "production":
        raise RuntimeError("SECRET_KEY and JWT_SECRET_KEY must be set in production")
    app.config["SECRET_KEY"] = app.config["SECRET_KEY"] or "dev-only-change-before-deploy"
    app.config["JWT_SECRET_KEY"] = app.config["JWT_SECRET_KEY"] or "dev-only-change-before-deploy-jwt"

db = SQLAlchemy(app)
JWTManager(app)
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if x.strip()]
CORS(app, resources={r"/api/*": {"origins": origins}}, allow_headers=["Content-Type", "Authorization"])

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.BigInteger, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(190), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum("admin", "student"), nullable=False, default="student")
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class Course(db.Model):
    __tablename__ = "courses"
    id = db.Column(db.BigInteger, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    description = db.Column(db.Text)
    level = db.Column(db.Enum("beginner", "intermediate", "advanced"), nullable=False, default="beginner")
    status = db.Column(db.Enum("draft", "published", "archived"), nullable=False, default="draft")
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, server_default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

class Lesson(db.Model):
    __tablename__ = "lessons"
    id = db.Column(db.BigInteger, primary_key=True)
    course_id = db.Column(db.BigInteger, db.ForeignKey("courses.id", ondelete="CASCADE"), nullable=False, index=True)
    title = db.Column(db.String(180), nullable=False)
    content_type = db.Column(db.Enum("text", "video", "pdf", "quiz", "code"), nullable=False, default="text")
    content = db.Column(db.Text)
    media_url = db.Column(db.String(500))
    position = db.Column(db.Integer, nullable=False, default=1)
    is_published = db.Column(db.Boolean, nullable=False, default=False)

class Enrollment(db.Model):
    __tablename__ = "enrollments"
    id = db.Column(db.BigInteger, primary_key=True)
    student_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    course_id = db.Column(db.BigInteger, db.ForeignKey("courses.id", ondelete="CASCADE"), nullable=False)
    progress = db.Column(db.Integer, nullable=False, default=0)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())
    __table_args__ = (db.UniqueConstraint("student_id", "course_id", name="uq_enrollment_student_course"),)

class Exam(db.Model):
    __tablename__ = "exams"
    id = db.Column(db.BigInteger, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    course_id = db.Column(db.BigInteger, db.ForeignKey("courses.id", ondelete="SET NULL"), nullable=True)
    duration_minutes = db.Column(db.Integer, nullable=False, default=30)
    total_marks = db.Column(db.Integer, nullable=False, default=100)
    status = db.Column(db.Enum("draft", "published", "archived"), nullable=False, default="draft")
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class ProjectSubmission(db.Model):
    __tablename__ = "project_submissions"
    id = db.Column(db.BigInteger, primary_key=True)
    student_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = db.Column(db.String(180), nullable=False)
    description = db.Column(db.Text)
    file_name = db.Column(db.String(255))
    file_path = db.Column(db.String(500))
    status = db.Column(db.Enum("submitted", "review", "approved", "changes_requested"), nullable=False, default="submitted")
    feedback = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class Message(db.Model):
    __tablename__ = "messages"
    id = db.Column(db.BigInteger, primary_key=True)
    sender_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    recipient_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    body = db.Column(db.Text, nullable=False)
    read_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.BigInteger, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    body = db.Column(db.Text, nullable=False)
    audience = db.Column(db.String(120), nullable=False, default="all_students")
    status = db.Column(db.Enum("queued", "sent", "failed"), nullable=False, default="queued")
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.id"), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class AuditLog(db.Model):
    __tablename__ = "audit_logs"
    id = db.Column(db.BigInteger, primary_key=True)
    actor_id = db.Column(db.BigInteger, db.ForeignKey("users.id", ondelete="SET NULL"))
    action = db.Column(db.String(120), nullable=False)
    target_type = db.Column(db.String(80))
    target_id = db.Column(db.String(80))
    ip_address = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())


def fail(message, status=400):
    return jsonify(error=message), status

def user_payload(user):
    return {"id": int(user.id), "name": user.full_name, "email": user.email, "role": user.role}

def audit(action, target_type=None, target_id=None, actor_id=None):
    try:
        actor = actor_id if actor_id is not None else get_jwt_identity()
        db.session.add(AuditLog(actor_id=int(actor) if actor else None, action=action,
                                target_type=target_type, target_id=str(target_id) if target_id else None,
                                ip_address=(request.headers.get("X-Forwarded-For", request.remote_addr) or "")[:45]))
    except Exception:
        pass

def role_required(*roles):
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            claims = get_jwt()
            if claims.get("role") not in roles:
                return fail("You do not have permission to perform this action", 403)
            user = db.session.get(User, int(get_jwt_identity()))
            if not user or not user.is_active:
                return fail("Account is inactive", 403)
            return fn(*args, **kwargs)
        return wrapper
    return decorator

admin_required = role_required("admin")
student_required = role_required("student")

@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Cache-Control", "no-store")
    return response

@app.get("/api/health")
def health():
    try:
        db.session.execute(db.text("SELECT 1"))
        return jsonify(status="ok", database="connected", service="Tint Quest API")
    except Exception:
        db.session.rollback()
        return jsonify(status="degraded", database="unavailable", service="Tint Quest API"), 503

@app.post("/api/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    email, password = str(data.get("email", "")).strip().lower(), data.get("password", "")
    if not email or not isinstance(password, str) or not password:
        return fail("Email and password are required")
    user = User.query.filter_by(email=email, is_active=True).first()
    if not user or not check_password_hash(user.password_hash, password):
        return fail("Invalid email or password", 401)
    token = create_access_token(identity=str(user.id), additional_claims={"role": user.role})
    audit("auth.login", "user", user.id, actor_id=user.id)
    db.session.commit()
    return jsonify(access_token=token, user=user_payload(user))

@app.get("/api/auth/me")
@jwt_required()
def auth_me():
    user = db.session.get(User, int(get_jwt_identity()))
    if not user or not user.is_active: return fail("Account is inactive", 403)
    return jsonify(user=user_payload(user))

@app.post("/api/auth/logout")
@jwt_required()
def logout():
    # JWT is stateless; clients must discard the access token. For immediate server-side
    # revocation, add a token blocklist table before production use.
    audit("auth.logout", "user", get_jwt_identity()); db.session.commit()
    return jsonify(status="logged_out", message="Discard the access token on this device")

@app.get("/api/admin/dashboard")
@admin_required
def admin_dashboard():
    progress_values = [row[0] for row in db.session.query(Enrollment.progress).all()]
    return jsonify(students=User.query.filter_by(role="student", is_active=True).count(),
                   courses=Course.query.count(), published_courses=Course.query.filter_by(status="published").count(),
                   active_exams=Exam.query.filter_by(status="published").count(),
                   pending_reviews=ProjectSubmission.query.filter(ProjectSubmission.status.in_(["submitted", "review"])).count(),
                   average_completion=round(sum(progress_values) / len(progress_values), 1) if progress_values else 0,
                   recent_notifications=Notification.query.order_by(Notification.created_at.desc()).limit(5).count())

@app.get("/api/admin/students")
@admin_required
def list_students():
    query = User.query.filter_by(role="student")
    term = request.args.get("q", "").strip()
    if term: query = query.filter(db.or_(User.full_name.ilike(f"%{term}%"), User.email.ilike(f"%{term}%")))
    result = []
    for u in query.order_by(User.full_name).limit(500).all():
        enrollments = db.session.query(Enrollment, Course).join(Course, Course.id == Enrollment.course_id).filter(Enrollment.student_id == u.id).order_by(Enrollment.created_at.desc()).all()
        progress = round(sum(e.progress for e, _ in enrollments) / len(enrollments)) if enrollments else None
        course = enrollments[0][1].title if enrollments else "—"
        result.append(user_payload(u) | {"status": "Active" if u.is_active else "Inactive", "course": course, "progress": progress, "score": None})
    return jsonify(result)

@app.post("/api/admin/students")
@admin_required
def create_student():
    data = request.get_json(silent=True) or {}
    name, email, password = str(data.get("name", "")).strip(), str(data.get("email", "")).strip().lower(), data.get("password", "")
    if not name or len(name) > 120: return fail("A valid student name is required")
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email): return fail("A valid email address is required")
    if not isinstance(password, str) or len(password) < 12: return fail("Initial password must be at least 12 characters")
    if User.query.filter_by(email=email).first(): return fail("An account with this email already exists", 409)
    student = User(full_name=name, email=email, password_hash=generate_password_hash(password), role="student")
    db.session.add(student); db.session.flush(); audit("student.create", "user", student.id); db.session.commit()
    return jsonify(user=user_payload(student)), 201

@app.patch("/api/admin/students/<int:user_id>/status")
@admin_required
def update_student_status(user_id):
    user = db.session.get(User, user_id)
    if not user or user.role != "student": return fail("Student not found", 404)
    active = (request.get_json(silent=True) or {}).get("active")
    if not isinstance(active, bool): return fail("active must be true or false")
    user.is_active = active; audit("student.status", "user", user.id); db.session.commit()
    return jsonify(user=user_payload(user), active=user.is_active)

@app.get("/api/admin/courses")
@admin_required
def list_courses():
    rows = Course.query.order_by(Course.created_at.desc()).limit(500).all()
    return jsonify([{"id": int(c.id), "title": c.title, "description": c.description or "", "level": c.level.title(),
                     "status": c.status.title(), "lessons": Lesson.query.filter_by(course_id=c.id).count(),
                     "enrolled": Enrollment.query.filter_by(course_id=c.id).count()} for c in rows])

@app.post("/api/admin/courses")
@admin_required
def create_course():
    data = request.get_json(silent=True) or {}
    title, level = str(data.get("title", "")).strip(), str(data.get("level", "beginner")).lower()
    if not title or len(title) > 180: return fail("Course title is required and must be under 180 characters")
    if level not in {"beginner", "intermediate", "advanced"}: return fail("Invalid course level")
    c = Course(title=title, description=str(data.get("description", ""))[:10000], level=level,
               status="draft", created_by=int(get_jwt_identity()))
    db.session.add(c); db.session.flush(); audit("course.create", "course", c.id); db.session.commit()
    return jsonify(id=int(c.id), title=c.title, description=c.description or "", level=c.level.title(), status="Draft", lessons=0, enrolled=0), 201

@app.patch("/api/admin/courses/<int:course_id>")
@admin_required
def update_course(course_id):
    c = db.session.get(Course, course_id)
    if not c: return fail("Course not found", 404)
    data = request.get_json(silent=True) or {}
    if "title" in data:
        title = str(data["title"]).strip()
        if not title or len(title) > 180: return fail("Invalid course title")
        c.title = title
    if "description" in data: c.description = str(data["description"])[:10000]
    if "level" in data:
        level = str(data["level"]).lower()
        if level not in {"beginner", "intermediate", "advanced"}: return fail("Invalid course level")
        c.level = level
    if "status" in data:
        status = str(data["status"]).lower()
        if status not in {"draft", "published", "archived"}: return fail("Invalid course status")
        c.status = status
    audit("course.update", "course", c.id); db.session.commit()
    return jsonify(id=int(c.id), title=c.title, description=c.description or "", level=c.level.title(), status=c.status.title())

@app.delete("/api/admin/courses/<int:course_id>")
@admin_required
def delete_course(course_id):
    c = db.session.get(Course, course_id)
    if not c: return fail("Course not found", 404)
    audit("course.delete", "course", c.id); db.session.delete(c); db.session.commit()
    return jsonify(status="deleted")

@app.get("/api/admin/courses/<int:course_id>/lessons")
@admin_required
def list_lessons(course_id):
    if not db.session.get(Course, course_id): return fail("Course not found", 404)
    rows = Lesson.query.filter_by(course_id=course_id).order_by(Lesson.position, Lesson.id).all()
    return jsonify([{"id": int(x.id), "course_id": int(x.course_id), "title": x.title, "content_type": x.content_type,
                     "content": x.content or "", "media_url": x.media_url, "position": x.position, "is_published": x.is_published} for x in rows])

@app.post("/api/admin/courses/<int:course_id>/lessons")
@admin_required
def create_lesson(course_id):
    if not db.session.get(Course, course_id): return fail("Course not found", 404)
    d = request.get_json(silent=True) or {}; title = str(d.get("title", "")).strip(); typ = str(d.get("content_type", "text"))
    if not title or len(title) > 180: return fail("Lesson title is required")
    if typ not in {"text", "video", "pdf", "quiz", "code"}: return fail("Invalid lesson type")
    lesson = Lesson(course_id=course_id, title=title, content_type=typ, content=str(d.get("content", ""))[:100000],
                    media_url=(str(d["media_url"])[:500] if d.get("media_url") else None),
                    position=int(d.get("position", 1)), is_published=bool(d.get("is_published", False)))
    db.session.add(lesson); audit("lesson.create", "lesson", lesson.id); db.session.commit()
    return jsonify(id=int(lesson.id), title=lesson.title, course_id=course_id), 201

@app.get("/api/admin/exams")
@admin_required
def list_exams():
    rows = Exam.query.order_by(Exam.created_at.desc()).limit(500).all()
    return jsonify([{"id": int(e.id), "title": e.title, "course_id": int(e.course_id) if e.course_id else None,
                     "duration_minutes": e.duration_minutes, "total_marks": e.total_marks, "status": e.status.title()} for e in rows])

@app.post("/api/admin/exams")
@admin_required
def create_exam():
    d = request.get_json(silent=True) or {}; title = str(d.get("title", "")).strip()
    try: duration, marks = int(d.get("duration_minutes", 30)), int(d.get("total_marks", 100))
    except (TypeError, ValueError): return fail("Duration and marks must be integers")
    if not title or len(title) > 180: return fail("Exam title is required")
    if not 1 <= duration <= 600 or not 1 <= marks <= 10000: return fail("Exam duration or marks are out of range")
    course_id = d.get("course_id")
    if course_id and not db.session.get(Course, int(course_id)): return fail("Course not found")
    e = Exam(title=title, course_id=int(course_id) if course_id else None, duration_minutes=duration,
             total_marks=marks, status="draft", created_by=int(get_jwt_identity()))
    db.session.add(e); db.session.flush(); audit("exam.create", "exam", e.id); db.session.commit()
    return jsonify(id=int(e.id), title=e.title, status="Draft"), 201

@app.get("/api/admin/projects")
@admin_required
def admin_projects():
    rows = ProjectSubmission.query.order_by(ProjectSubmission.created_at.desc()).limit(500).all()
    return jsonify([{"id": int(p.id), "student_id": int(p.student_id), "student": (db.session.get(User, p.student_id).full_name if db.session.get(User, p.student_id) else "Unknown"),
                     "title": p.title, "description": p.description or "", "file_name": p.file_name, "status": p.status,
                     "feedback": p.feedback or "", "created_at": p.created_at.isoformat() if p.created_at else None} for p in rows])

@app.patch("/api/admin/projects/<int:project_id>")
@admin_required
def review_project(project_id):
    p = db.session.get(ProjectSubmission, project_id)
    if not p: return fail("Submission not found", 404)
    d = request.get_json(silent=True) or {}; status = str(d.get("status", "review")); feedback = str(d.get("feedback", ""))[:10000]
    if status not in {"submitted", "review", "approved", "changes_requested"}: return fail("Invalid review status")
    p.status, p.feedback = status, feedback; audit("project.review", "project", p.id); db.session.commit()
    return jsonify(id=int(p.id), status=p.status, feedback=p.feedback)

@app.get("/api/admin/notifications")
@admin_required
def list_notifications():
    rows = Notification.query.order_by(Notification.created_at.desc()).limit(200).all()
    return jsonify([{"id": int(n.id), "title": n.title, "body": n.body, "audience": n.audience,
                     "status": n.status, "date": n.created_at.isoformat() if n.created_at else None} for n in rows])

@app.post("/api/admin/notifications")
@admin_required
def create_notification():
    d = request.get_json(silent=True) or {}; title, body = str(d.get("title", "")).strip(), str(d.get("body", "")).strip()
    audience = str(d.get("audience", "all_students")).strip()
    if not title or not body: return fail("Title and message body are required")
    if len(title) > 180 or len(body) > 10000: return fail("Notification exceeds allowed length")
    n = Notification(title=title, body=body, audience=audience[:120], status="queued", created_by=int(get_jwt_identity()))
    db.session.add(n); db.session.flush(); audit("notification.create", "notification", n.id); db.session.commit()
    return jsonify(id=int(n.id), status=n.status), 201

@app.get("/api/admin/messages/<int:student_id>")
@admin_required
def admin_messages(student_id):
    student = db.session.get(User, student_id)
    if not student or student.role != "student": return fail("Student not found", 404)
    admin_id = int(get_jwt_identity())
    rows = Message.query.filter(db.or_(db.and_(Message.sender_id == admin_id, Message.recipient_id == student_id),
                                       db.and_(Message.sender_id == student_id, Message.recipient_id == admin_id))).order_by(Message.created_at.asc()).limit(500).all()
    return jsonify([{"id": int(m.id), "from": "Admin" if m.sender_id == admin_id else student.full_name,
                     "sender_id": int(m.sender_id), "recipient_id": int(m.recipient_id), "text": m.body,
                     "created_at": m.created_at.isoformat() if m.created_at else None} for m in rows])

@app.post("/api/admin/messages/<int:student_id>")
@admin_required
def send_admin_message(student_id):
    student = db.session.get(User, student_id)
    if not student or student.role != "student": return fail("Student not found", 404)
    body = str((request.get_json(silent=True) or {}).get("body", "")).strip()
    if not body or len(body) > 10000: return fail("Message is required and must be under 10,000 characters")
    m = Message(sender_id=int(get_jwt_identity()), recipient_id=student_id, body=body)
    db.session.add(m); audit("message.send", "user", student_id); db.session.commit()
    return jsonify(id=int(m.id), text=m.body), 201

@app.get("/api/student/me")
@student_required
def student_me():
    u = db.session.get(User, int(get_jwt_identity()))
    return jsonify(user=user_payload(u))

@app.get("/api/student/courses")
@student_required
def student_courses():
    uid = int(get_jwt_identity())
    rows = db.session.query(Course, Enrollment).join(Enrollment, Enrollment.course_id == Course.id).filter(
        Enrollment.student_id == uid, Course.status == "published").order_by(Course.title).all()
    return jsonify([{"id": int(c.id), "title": c.title, "description": c.description or "", "level": c.level.title(),
                     "progress": e.progress, "lessons": Lesson.query.filter_by(course_id=c.id, is_published=True).count()} for c, e in rows])

@app.get("/api/student/progress")
@student_required
def student_progress():
    uid = int(get_jwt_identity())
    rows = db.session.query(Enrollment, Course).join(Course, Course.id == Enrollment.course_id).filter(Enrollment.student_id == uid).all()
    return jsonify(courses=[{"course_id": int(c.id), "title": c.title, "progress": e.progress} for e, c in rows],
                   overall=round(sum(e.progress for e, _ in rows) / len(rows)) if rows else 0)

@app.get("/api/student/notifications")
@student_required
def student_notifications():
    rows = Notification.query.filter(Notification.status == "sent").order_by(Notification.created_at.desc()).limit(100).all()
    return jsonify([{"id": int(n.id), "title": n.title, "body": n.body, "created_at": n.created_at.isoformat() if n.created_at else None} for n in rows])

@app.get("/api/student/messages")
@student_required
def student_messages():
    uid = int(get_jwt_identity())
    rows = Message.query.filter(db.or_(Message.sender_id == uid, Message.recipient_id == uid)).order_by(Message.created_at.asc()).limit(500).all()
    return jsonify([{"id": int(m.id), "sender_id": int(m.sender_id), "recipient_id": int(m.recipient_id), "text": m.body,
                     "created_at": m.created_at.isoformat() if m.created_at else None} for m in rows])

@app.post("/api/student/messages")
@student_required
def student_send_message():
    d = request.get_json(silent=True) or {}; body = str(d.get("body", "")).strip()
    recipient = User.query.filter_by(role="admin", is_active=True).order_by(User.id).first()
    if not recipient: return fail("No support administrator is available", 503)
    if not body or len(body) > 10000: return fail("Message is required and must be under 10,000 characters")
    m = Message(sender_id=int(get_jwt_identity()), recipient_id=recipient.id, body=body); db.session.add(m); db.session.commit()
    return jsonify(id=int(m.id), status="sent"), 201

@app.post("/api/student/projects")
@student_required
def student_submit_project():
    d = request.get_json(silent=True) or {}; title = str(d.get("title", "")).strip(); description = str(d.get("description", ""))
    if not title or len(title) > 180: return fail("Project title is required")
    if len(description) > 10000: return fail("Description is too long")
    p = ProjectSubmission(student_id=int(get_jwt_identity()), title=title, description=description, status="submitted")
    db.session.add(p); db.session.commit(); return jsonify(id=int(p.id), status=p.status), 201

@app.errorhandler(404)
def not_found(_): return jsonify(error="Route not found"), 404

@app.errorhandler(413)
def too_large(_): return jsonify(error="Request payload too large"), 413

@app.errorhandler(500)
def server_error(_):
    db.session.rollback()
    return jsonify(error="Internal server error"), 500

@app.cli.command("init-db")
def init_db_command():
    """Create missing tables from the current models."""
    with app.app_context():
        db.create_all()
    print("Database tables are ready.")

@app.cli.command("create-admin")
def create_admin_command():
    """Create the first admin interactively: flask --app app create-admin"""
    import getpass
    name = input("Admin full name: ").strip()
    email = input("Admin email: ").strip().lower()
    password = getpass.getpass("Password (minimum 12 characters): ")
    if not name or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email) or len(password) < 12:
        raise SystemExit("Invalid name/email or password too short")
    if User.query.filter_by(email=email).first(): raise SystemExit("That email already exists")
    db.session.add(User(full_name=name, email=email, password_hash=generate_password_hash(password), role="admin"))
    db.session.commit()
    print("Admin account created.")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG", "0") == "1")
