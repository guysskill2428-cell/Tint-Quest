CREATE DATABASE IF NOT EXISTS tint_quest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tint_quest;
-- Schema is managed by Flask-SQLAlchemy with `flask --app app init-db` in the deployment guide.
-- This file creates the database and least-privilege app account placeholder only.
-- Run the CREATE USER/GRANT statements using a MySQL administrator and replace the password.
