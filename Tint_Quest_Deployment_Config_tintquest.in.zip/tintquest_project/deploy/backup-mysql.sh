#!/usr/bin/env bash
set -Eeuo pipefail
# Run on the VPS from the repository root. Requires Docker Compose and a private backup directory.
# Do not store backups in the public web root. Configure off-server copying separately.
BACKUP_DIR="${BACKUP_DIR:-/var/backups/tintquest}"
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$BACKUP_DIR/tintquest-mysql-$STAMP.sql.gz"
# The database root password is read from the protected project .env file by Compose.
docker compose exec -T db sh -lc 'exec mysqldump --single-transaction --routines --triggers -uroot -p"$MYSQL_ROOT_PASSWORD" tint_quest' | gzip -9 > "$OUT"
test -s "$OUT"
chmod 600 "$OUT"
# Retain 14 days locally; maintain a separate encrypted off-server copy for disaster recovery.
find "$BACKUP_DIR" -type f -name 'tintquest-mysql-*.sql.gz' -mtime +14 -delete
printf 'Created %s\n' "$OUT"
