# Tint Quest Ubuntu VPS deployment checklist

This is an operator runbook, not proof of a live deployment. Do not put passwords, SSH private keys, or payment information into chat or source control.

## Before starting

- Provision an Ubuntu 24.04 LTS VPS. Suggested starting size based on the previously discussed workload: 4 vCPU, 8 GB RAM, 100 GB SSD/NVMe; confirm the provider's current price and renewal terms before paying.
- Register `tintquest.in` only if available, then create `A` records for both `@` (apex) and `www` pointing to the VPS public IPv4. This configuration does not check availability or register the domain. Wait until both DNS names resolve to the server.
- Configure SSH key access at the provider and test a second SSH session before disabling password login. Keep your existing SSH session open while changing firewall/SSH settings.
- Back up any existing files before deploying over them.

## 1. Secure the host

```bash
sudo apt update && sudo apt full-upgrade -y
sudo apt install -y nginx certbot python3-certbot-nginx ufw ca-certificates curl gnupg
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status verbose
```

Install Docker Engine and the Compose plugin using Docker's official Ubuntu installation guide. Verify with `docker --version` and `docker compose version`. Do not open ports 3306, 5000, or 8080 to the public internet; the Compose file binds the web/API host ports to loopback and keeps MySQL on a private Docker network.

## 2. Upload and configure the project

Upload the cleaned project ZIP to the VPS using SFTP/SCP, then use its actual filename in the `unzip` command below. The archive contains the `tintquest_project/` directory. Example:

```bash
mkdir -p ~/tintquest-deploy
unzip Tint_Quest_Integrated_Project_Clean.zip -d ~/tintquest-deploy
cd ~/tintquest-deploy/tintquest_project
cp .env.production.example .env
chmod 600 .env
```

Edit `.env` with unique, long, randomly generated values for all four secrets/passwords. Do not reuse passwords. Set `CORS_ORIGINS` to the exact HTTPS origin used for the admin site, with no trailing slash. Check `docker-compose.yml` and `.env` before launch.

Start the services and create the schema/admin:

```bash
docker compose config
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 api web db
docker compose exec api flask --app app init-db
docker compose exec api flask --app app create-admin
curl -fsS http://127.0.0.1:5000/api/health
```

The admin creation command prompts for an admin name, email and password. Use a unique password of at least 12 characters. Do not create a demo account.

## 3. Configure Nginx and HTTPS

Copy `deploy/nginx-tintquest.conf` to `/etc/nginx/sites-available/tintquest`, the included configuration already uses `tintquest.in` and `www.tintquest.in`, then:

```bash
sudo ln -s /etc/nginx/sites-available/tintquest /etc/nginx/sites-enabled/tintquest
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d tintquest.in -d www.tintquest.in
sudo certbot renew --dry-run
```

Only run Certbot after the DNS A record points to this VPS and port 80 is reachable. Confirm HTTPS works externally. Keep the Nginx config and TLS renewal tested after changes.

## 4. Smoke tests

- Open `https://tintquest.in` (and optionally `https://www.tintquest.in`) and sign in using the administrator account created on the server.
- Create a course, create a student, create an exam draft, and queue a notification; confirm data survives a container restart.
- Test messaging and project review with a real test student account.
- Verify an unauthenticated request to admin endpoints returns 401 and a student token cannot access admin endpoints.
- Confirm `http://SERVER_IP:3306`, `:5000`, and `:8080` are not publicly reachable.
- Verify logs contain no passwords/tokens and no debug mode is enabled.
- Run an actual restore test before using real student data.

## 5. Backups and operations

Run `deploy/backup-mysql.sh` from the repository root. Store an encrypted copy off the VPS, restrict access, and test restoring it into a separate database. Back up user-uploaded files separately if file upload support is later implemented. Configure automatic security updates and uptime/log alerts. The script keeps 14 days of local dumps only; it is not a substitute for off-server backups.

## Known blockers before real student data / public launch

- The student Flutter UI is not fully wired to the API yet; release login/session handling and screen-by-screen data integration remain to be completed and tested.
- Some admin analytics, security preferences, help, exam authoring/questions, and delivery statuses remain demo/prototype-only.
- File uploads are not implemented; project submissions currently store metadata only. Student demo-video upload remains intentionally excluded.
- Notifications are queued in the database; no delivery worker/provider is included.
- JWT logout does not revoke tokens server-side yet; add a token blocklist/revocation mechanism before relying on immediate logout.
- No password reset/change flow, formal migrations, comprehensive automated tests, or isolated code-execution sandbox is included. Do not enable arbitrary code execution without a separate resource-limited sandbox.
- The project package uses floating `latest` versions for some frontend dependencies; lock and audit dependencies before a production release.
