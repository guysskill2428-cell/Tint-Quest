# Tint Quest domain configuration — prepared, not activated

Target domain: `tintquest.in` (availability not checked; not purchased).

## DNS records to create after registration

| Type | Name | Value |
|---|---|---|
| A | `@` | Your VPS public IPv4 address |
| A | `www` | Your VPS public IPv4 address |

Do not replace the values with an IP until the VPS exists. If your VPS provider assigns IPv6 and you want to use it, add an AAAA record only after confirming IPv6 connectivity and firewall rules.

## Host config

- Nginx site file: `deploy/nginx-tintquest.conf`
- Admin portal origin: `https://tintquest.in`
- Optional `www` origin: `https://www.tintquest.in`
- API base in browser: `/api` (same-origin reverse proxy)
- CORS allowlist: `https://tintquest.in,https://www.tintquest.in`
- TLS names: `tintquest.in` and `www.tintquest.in`

## Activation sequence

1. Register the domain after checking availability and renewal pricing at checkout.
2. Purchase/provision the Ubuntu VPS and note its public IPv4 address.
3. Create both DNS A records above and wait for propagation.
4. Upload/extract the project, configure a private `.env`, and start containers.
5. Install the Nginx site file and validate with `sudo nginx -t`.
6. Obtain TLS only after DNS resolves and port 80 is reachable: `sudo certbot --nginx -d tintquest.in -d www.tintquest.in`.
7. Test HTTPS, authentication, API routes, backup/restore, and ensure MySQL (3306) and app ports (5000/8080) are not publicly exposed.

**Status:** configuration prepared only. No domain purchase, DNS change, VPS provisioning, certificate issuance, or live deployment has occurred.
