# Tint Quest — existing project integration

This repository preserves the existing purple Tint Quest admin UI and Flutter student app. It adds a self-hosted Flask API, MySQL data models, API-backed admin sign-in, and live server integration for admin course creation/deletion, student listing, notifications, and private messages. The API is custom and self-hosted; it does not rely on Firebase or another hosted backend.

## Project layout

- `frontend/` — existing React + Vite admin portal; UI styles remain in `src/styles.css`.
- `Tint_Quest_Student_App/` — existing Flutter Android student app.
- `backend/` — Flask REST API, JWT access tokens, password hashing, role checks, MySQL models, audit events, and student/admin endpoints.
- `docker-compose.yml` — MySQL, API, and admin web app for a single-server deployment.

## API coverage

- `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/logout`
- Admin: dashboard, student list/create/status, courses list/create/update/delete, lessons list/create, exams list/create, project review/list, notifications list/create, private messages read/send
- Student: profile, enrolled courses, progress, notifications, private messages read/send, project submission
- `GET /api/health` checks the database connection

**Important scope note:** some admin pages (exam editing/questions, file upload, analytics charts) and several Flutter screens still contain prototype UI/sample content. The backend has foundational endpoints for exams/projects, but the whole product is not yet feature-complete. File uploads and arbitrary-code execution are intentionally not enabled. Do not expose a code runner until it runs in a separate, resource-limited sandbox.

## Local development

Requirements: Python 3.12+, Node.js 20+, MySQL 8.4, Flutter stable + Android SDK for Android builds.

### 1. Start MySQL

Create a database and a least-privilege user. Example for a local MySQL administrator (replace the password):

```sql
CREATE DATABASE tint_quest CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'tintquest_user'@'localhost' IDENTIFIED BY 'replace-with-a-long-password';
GRANT ALL PRIVILEGES ON tint_quest.* TO 'tintquest_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Start the API

```bash
cd backend
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
# Edit DATABASE_URL and set distinct random SECRET_KEY / JWT_SECRET_KEY values
flask --app app init-db
flask --app app create-admin
flask --app app run --host 0.0.0.0 --port 5000
```

`create-admin` prompts for a name, email, and password; the password must be at least 12 characters. No demo admin account is created.

### 3. Start the React admin portal

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Set `VITE_API_BASE=http://127.0.0.1:5000/api` in `frontend/.env` for local Vite development. Sign in with the administrator account created in step 2.

### 4. Android app

```bash
cd Tint_Quest_Student_App
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:5000/api
```

`10.0.2.2` is the Android emulator's route to the development host. For a physical phone use your computer's LAN IP during development; for release use your HTTPS API URL. The current student UI still needs screen-by-screen API wiring and secure token/session handling before production release.

## Single-server Docker deployment

1. Copy `.env.production.example` to `.env` in the repository root.
2. Set unique, long random values for `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD`, `SECRET_KEY`, and `JWT_SECRET_KEY`. Never commit `.env`.
3. Set `CORS_ORIGINS` to the final HTTPS admin origin.
4. Start services:

```bash
docker compose up -d --build
docker compose exec api flask --app app init-db
docker compose exec api flask --app app create-admin
```

The admin portal is available on `http://127.0.0.1:8080` on the server. Put a TLS reverse proxy (for example, a host-managed Nginx/Caddy configuration) in front of port 8080 before public launch. Do not expose MySQL publicly. Back up the `mysql_data` volume and test restore procedures.

The API is bound to `127.0.0.1:5000` on the host for local health checks; the web container proxies `/api/` to the API over the private Docker network. For production, use HTTPS, firewall rules, OS security updates, log monitoring, rate limiting at the reverse proxy, database backups, and tested recovery procedures.

## Android release build

```bash
cd Tint_Quest_Student_App
flutter pub get
flutter build appbundle --release --dart-define=API_BASE_URL=https://api.your-domain.example/api
```

The signing key and Play Console submission must be configured by the app owner. Never put database credentials or server secrets in the Android app.

## Security notes before public launch

- Access tokens expire after 30 minutes by default. Client logout discards the token; immediate server-side JWT revocation is not implemented yet.
- Add persistent token revocation, rate limiting, password reset/change flows, CSRF protection if cookie auth is introduced, and formal database migrations before handling real student data.
- Notification records are stored as queued; a delivery worker/provider is not included.
- Uploads, online code execution, exam question authoring/grading, and production analytics are not complete.
- Configure privacy notice, consent/retention rules, least-privilege roles, monitoring, backups, and incident response for real student records.

## Design preservation

The current React admin interface and CSS have been retained, including its existing purple Tint Quest theme. The Figma dashboard was inspected for navigation and design context, but a full pixel-by-pixel audit of all Figma frames has not yet been completed. See `DESIGN_NOTES.md` for the next visual verification stage. The original standalone HTML prototype is preserved under `reference/` and is not used by the deployment build.

## Ubuntu deployment assets

- `deploy/DEPLOY_UBUNTU.md` — VPS setup, Docker deployment, domain/Nginx/HTTPS, smoke tests, and operational blockers.
- `deploy/nginx-tintquest.conf` — host Nginx reverse-proxy template; replace the example hostname before enabling.
- `deploy/backup-mysql.sh` — local compressed MySQL dump script with restricted file permissions and 14-day local retention. Configure encrypted off-server backups separately.

## Validation performed in this workspace

- Python syntax compilation passed for `backend/app.py`.
- Frontend dependency installation/build could not be completed within the available command window; a successful frontend build is therefore **not verified**.
- Docker and Flutter CLIs are not available in this workspace, so container startup, Android compilation, end-to-end integration, TLS, and real-server deployment have **not been verified**.
- No VPS or domain has been provisioned from this workspace. This package is a deployable starting point, not a claim that Tint Quest is live or production-certified.
